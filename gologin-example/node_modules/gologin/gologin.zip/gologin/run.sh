DISPLAY=:$5 $1 --remote-debugging-port=$2 --proxy-server=$3 --user-data-dir=$4 --tz=$6 --load-extension=$7 --password-store=basic --lang=en --new-window
