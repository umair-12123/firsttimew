export const STORAGE_GATEWAY_BASE_URL = 'https://files-gateway.gologin.com';
